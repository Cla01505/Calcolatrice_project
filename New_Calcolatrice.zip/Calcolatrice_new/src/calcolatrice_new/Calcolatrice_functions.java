/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package calcolatrice_new;

/**
 *
 * @author claud
 */
public class Calcolatrice_functions extends javax.swing.JFrame {

    //inizializzazione variabili
     
    double numero_1=0;
     double numero_2=0;
     double risultato=0;
     String operazioni;
     String num;
    public Calcolatrice_functions() {
        initComponents();
       
    }

    // metodo di inserimento bottoni
   
    public void inserimento_bottoni(String n){
        num= jTextArea1.getText()+n;
        jTextArea1.setText(num);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bottone1 = new javax.swing.JButton();
        bottone2 = new javax.swing.JButton();
        bottone3 = new javax.swing.JButton();
        bottone_più = new javax.swing.JButton();
        bottone4 = new javax.swing.JButton();
        bottone5 = new javax.swing.JButton();
        bottone6 = new javax.swing.JButton();
        bottone_meno = new javax.swing.JButton();
        bottone7 = new javax.swing.JButton();
        bottone8 = new javax.swing.JButton();
        bottone9 = new javax.swing.JButton();
        bottone_per = new javax.swing.JButton();
        bottonecanc = new javax.swing.JButton();
        bottone0 = new javax.swing.JButton();
        bottone_uguale = new javax.swing.JButton();
        bottone_diviso = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        bottone_delete = new javax.swing.JButton();
        bottone_virgola = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        bottone1.setBackground(new java.awt.Color(0, 0, 0));
        bottone1.setForeground(new java.awt.Color(255, 255, 255));
        bottone1.setText("1");
        bottone1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone1ActionPerformed(evt);
            }
        });

        bottone2.setBackground(new java.awt.Color(0, 0, 0));
        bottone2.setForeground(new java.awt.Color(255, 255, 255));
        bottone2.setText("2");
        bottone2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone2ActionPerformed(evt);
            }
        });

        bottone3.setBackground(new java.awt.Color(0, 0, 0));
        bottone3.setForeground(new java.awt.Color(255, 255, 255));
        bottone3.setText("3");
        bottone3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone3ActionPerformed(evt);
            }
        });

        bottone_più.setBackground(new java.awt.Color(0, 0, 0));
        bottone_più.setForeground(new java.awt.Color(255, 255, 255));
        bottone_più.setText("+");
        bottone_più.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_piùActionPerformed(evt);
            }
        });

        bottone4.setBackground(new java.awt.Color(0, 0, 0));
        bottone4.setForeground(new java.awt.Color(255, 255, 255));
        bottone4.setText("4");
        bottone4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone4ActionPerformed(evt);
            }
        });

        bottone5.setBackground(new java.awt.Color(0, 0, 0));
        bottone5.setForeground(new java.awt.Color(255, 255, 255));
        bottone5.setText("5");
        bottone5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone5ActionPerformed(evt);
            }
        });

        bottone6.setBackground(new java.awt.Color(0, 0, 0));
        bottone6.setForeground(new java.awt.Color(255, 255, 255));
        bottone6.setText("6");
        bottone6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone6ActionPerformed(evt);
            }
        });

        bottone_meno.setBackground(new java.awt.Color(0, 0, 0));
        bottone_meno.setForeground(new java.awt.Color(255, 255, 255));
        bottone_meno.setText("-");
        bottone_meno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_menoActionPerformed(evt);
            }
        });

        bottone7.setBackground(new java.awt.Color(0, 0, 0));
        bottone7.setForeground(new java.awt.Color(255, 255, 255));
        bottone7.setText("7");
        bottone7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone7ActionPerformed(evt);
            }
        });

        bottone8.setBackground(new java.awt.Color(0, 0, 0));
        bottone8.setForeground(new java.awt.Color(255, 255, 255));
        bottone8.setText("8");
        bottone8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone8ActionPerformed(evt);
            }
        });

        bottone9.setBackground(new java.awt.Color(0, 0, 0));
        bottone9.setForeground(new java.awt.Color(255, 255, 255));
        bottone9.setText("9");
        bottone9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone9ActionPerformed(evt);
            }
        });

        bottone_per.setBackground(new java.awt.Color(0, 0, 0));
        bottone_per.setForeground(new java.awt.Color(255, 255, 255));
        bottone_per.setText("x");
        bottone_per.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_perActionPerformed(evt);
            }
        });

        bottonecanc.setBackground(new java.awt.Color(0, 0, 0));
        bottonecanc.setText("C");
        bottonecanc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottonecancActionPerformed(evt);
            }
        });

        bottone0.setBackground(new java.awt.Color(0, 0, 0));
        bottone0.setForeground(new java.awt.Color(255, 255, 255));
        bottone0.setText("0");
        bottone0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone0ActionPerformed(evt);
            }
        });

        bottone_uguale.setBackground(new java.awt.Color(0, 0, 0));
        bottone_uguale.setForeground(new java.awt.Color(255, 255, 255));
        bottone_uguale.setText("=");
        bottone_uguale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_uguale(evt);
            }
        });

        bottone_diviso.setBackground(new java.awt.Color(0, 0, 0));
        bottone_diviso.setForeground(new java.awt.Color(255, 255, 255));
        bottone_diviso.setText(":");
        bottone_diviso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_divisoActionPerformed(evt);
            }
        });

        jTextArea1.setBackground(new java.awt.Color(204, 204, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(1);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea1);
        jTextArea1.getAccessibleContext().setAccessibleParent(jTextArea1);

        bottone_delete.setBackground(new java.awt.Color(0, 0, 0));
        bottone_delete.setForeground(new java.awt.Color(255, 255, 255));
        bottone_delete.setText("DEL");
        bottone_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_deleteActionPerformed(evt);
            }
        });

        bottone_virgola.setBackground(new java.awt.Color(0, 0, 0));
        bottone_virgola.setForeground(new java.awt.Color(255, 255, 255));
        bottone_virgola.setText(".");
        bottone_virgola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottone_virgolaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(bottone_delete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bottone_più, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bottone1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bottone2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bottone3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bottone4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bottone5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bottone6, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bottone7, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bottone8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bottone9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(bottonecanc, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bottone0, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bottone_virgola, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bottone_uguale, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bottone_diviso, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bottone_per, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bottone_meno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bottone_più, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone_delete))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bottone1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone_meno, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bottone4, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone_per, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bottone7, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone8, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone_diviso, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bottone_uguale, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone_virgola, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottone0, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bottonecanc, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bottone2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone2ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("2");
    }//GEN-LAST:event_bottone2ActionPerformed

    private void bottone5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone5ActionPerformed
        // TODO add your handling code here:
       inserimento_bottoni("5");
    }//GEN-LAST:event_bottone5ActionPerformed

    private void bottone1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone1ActionPerformed
        // TODO add your handling code here:
       inserimento_bottoni("1");
    }//GEN-LAST:event_bottone1ActionPerformed

    private void bottone_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_deleteActionPerformed
        // TODO add your handling code here:
        String del=null;
        
        if(jTextArea1.getText().length()>0){
            StringBuilder delete= new StringBuilder(jTextArea1.getText());
            delete.deleteCharAt(jTextArea1.getText().length()-1);
            del=delete.toString();
            jTextArea1.setText(del);
        }
    }//GEN-LAST:event_bottone_deleteActionPerformed

    private void bottone_uguale(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_uguale
        // TODO add your handling code here:
        numero_2=Double.parseDouble(jTextArea1.getText());
              if("+".equals(operazioni)){
            risultato=numero_1 + numero_2;
        }
        else if("-".equals(operazioni)){
            risultato=numero_1 - numero_2;
        }
        else if("X".equals(operazioni)){
            risultato=numero_1 * numero_2;
        }
        else if(":".equals(operazioni)){
            risultato=numero_1 / numero_2;
        }
         jTextArea1.setText(String.valueOf(risultato));
         
    }//GEN-LAST:event_bottone_uguale

    private void bottone3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone3ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("3");
    }//GEN-LAST:event_bottone3ActionPerformed

    private void bottone4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone4ActionPerformed
        // TODO add your handling code here:
       inserimento_bottoni("4");
    }//GEN-LAST:event_bottone4ActionPerformed

    private void bottone6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone6ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("6");
    }//GEN-LAST:event_bottone6ActionPerformed

    private void bottone7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone7ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("7");
    }//GEN-LAST:event_bottone7ActionPerformed

    private void bottone8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone8ActionPerformed
        // TODO add your handling code here:
       inserimento_bottoni("8");
    }//GEN-LAST:event_bottone8ActionPerformed

    private void bottone9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone9ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("9");
    }//GEN-LAST:event_bottone9ActionPerformed

    private void bottone0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone0ActionPerformed
        // TODO add your handling code here:
        inserimento_bottoni("0");
    }//GEN-LAST:event_bottone0ActionPerformed

    private void bottone_piùActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_piùActionPerformed
        // TODO add your handling code here:
        numero_1=Double.parseDouble(jTextArea1.getText());
        jTextArea1.setText("");
        operazioni="+";
    }//GEN-LAST:event_bottone_piùActionPerformed

    private void bottone_menoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_menoActionPerformed
        // TODO add your handling code here:
        numero_1=Double.parseDouble(jTextArea1.getText());
        jTextArea1.setText("");
        operazioni="-";
    }//GEN-LAST:event_bottone_menoActionPerformed

    private void bottone_perActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_perActionPerformed
        // TODO add your handling code here:
        numero_1=Double.parseDouble(jTextArea1.getText());
        jTextArea1.setText(" ");
        operazioni="X";
    }//GEN-LAST:event_bottone_perActionPerformed

    private void bottone_divisoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_divisoActionPerformed
        // TODO add your handling code here:
        numero_1=Double.parseDouble(jTextArea1.getText());
        jTextArea1.setText("");
        operazioni=":";
    }//GEN-LAST:event_bottone_divisoActionPerformed

    private void bottone_virgolaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottone_virgolaActionPerformed
        // TODO add your handling code here:
        if(!jTextArea1.getText().contains(".") && jTextArea1.getText().length()>0){
            jTextArea1.setText(jTextArea1.getText()+".");
        }
    }//GEN-LAST:event_bottone_virgolaActionPerformed

    private void bottonecancActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottonecancActionPerformed
        // TODO add your handling code here:
        jTextArea1.setText("");
        String p_numero;
        String s_numero;
        p_numero= String.valueOf(numero_1);
        s_numero= String.valueOf(numero_2);
        p_numero=" ";
        s_numero=" ";
        num="";
        numero_1=0;
        numero_2=0;
        risultato=0;
    }//GEN-LAST:event_bottonecancActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Calcolatrice_functions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Calcolatrice_functions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Calcolatrice_functions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Calcolatrice_functions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Calcolatrice_functions().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bottone0;
    private javax.swing.JButton bottone1;
    private javax.swing.JButton bottone2;
    private javax.swing.JButton bottone3;
    private javax.swing.JButton bottone4;
    private javax.swing.JButton bottone5;
    private javax.swing.JButton bottone6;
    private javax.swing.JButton bottone7;
    private javax.swing.JButton bottone8;
    private javax.swing.JButton bottone9;
    private javax.swing.JButton bottone_delete;
    private javax.swing.JButton bottone_diviso;
    private javax.swing.JButton bottone_meno;
    private javax.swing.JButton bottone_per;
    private javax.swing.JButton bottone_più;
    private javax.swing.JButton bottone_uguale;
    private javax.swing.JButton bottone_virgola;
    private javax.swing.JButton bottonecanc;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
